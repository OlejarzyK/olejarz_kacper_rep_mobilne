package com.example.graclicker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {




    int counter =0;
    int counter1 =0;
    int counter2 =0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void increaseInteger(View view){


        counter= counter+1;
        display(counter);

    }
    private void display(int counter){
        TextView displayInteger= findViewById(R.id.integer_number);
        displayInteger.setText(""+counter);
    }
    public void increaseInteger1(View view) {

        counter1= counter1+1;
        display1(counter1);
    }
    private void display1 (int counter1){
        TextView displayInteger1= findViewById(R.id.integer_number1);
        displayInteger1.setText(""+counter1);
    }
    public void increaseInteger2(View view) {


        counter2= counter2+1;
        display2(counter2);
    }
    private void display2 (int counter2){
        TextView displayInteger1= findViewById(R.id.integer_number);
        displayInteger1.setText(""+counter2);
    }


}